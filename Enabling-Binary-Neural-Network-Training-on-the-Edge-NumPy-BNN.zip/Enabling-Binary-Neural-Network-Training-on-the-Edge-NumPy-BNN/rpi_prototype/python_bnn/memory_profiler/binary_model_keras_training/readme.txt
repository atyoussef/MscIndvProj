Please see our environment setup in env.txt
To run our experiments, please go to MNIST-CIFAR-SVHN and execute python Binary.py
To change training settings, see Binary.py