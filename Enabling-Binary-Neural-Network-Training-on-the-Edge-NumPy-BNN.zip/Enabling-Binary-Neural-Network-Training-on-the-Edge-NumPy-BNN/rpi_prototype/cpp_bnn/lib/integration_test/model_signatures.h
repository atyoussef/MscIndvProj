#ifndef model_signatures_h
#define model_signatures_h

void ovw1d_xnor_model(int BATCH_SIZE, int EPOCH);



#endif