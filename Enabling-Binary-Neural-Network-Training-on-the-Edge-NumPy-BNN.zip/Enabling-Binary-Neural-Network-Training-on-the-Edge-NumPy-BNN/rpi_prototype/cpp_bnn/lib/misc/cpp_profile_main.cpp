//#include <iostream>
#include "initializers.h"

int main(void) {
    glorot_normal_initializer_2d(1024, 1024, 0);
    
    return 0;
}