#ifndef BATCH_NORM_H
#define BATCH_NORM_H

#include "data_types.h"



#endif