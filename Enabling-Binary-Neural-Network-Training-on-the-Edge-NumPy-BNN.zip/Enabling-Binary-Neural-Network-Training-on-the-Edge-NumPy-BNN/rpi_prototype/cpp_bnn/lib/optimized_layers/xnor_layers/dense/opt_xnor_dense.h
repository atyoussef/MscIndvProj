#ifndef opt_xnor_dense_h
#define opt_xnor_dense_h

#include "../../../utils/data_type.h"
#include "../../../utils/initialiser.h"
#include "../../../utils/bit_packing.h"
#include "../../../utils/base_layer.h"
#include "../../../utils/gradient_quantisation.h"
#include "../../../utils/optimized_matrix_operations.h"

class OPT_XNor_Dense : public BaseLayer<Matrix, float16_t> {
    public:
        bool is_built = false;
        bool is_training = false;
        bool is_first_layer = false;
        size_t units;
        int random_seed;
        Matrix<bool> packed_x;
        Matrix<float16_t> kernel;
        float gradient_scale;
        Matrix<bool> dkernel;
        //Constructors
        OPT_XNor_Dense(int units, bool is_first_layer = false, int random_seed=0);
        //Deconstructors
        ~OPT_XNor_Dense();
        Matrix<float16_t> forward(Matrix<float16_t> & x, bool is_training=false);
        Matrix<float16_t> backprop(Matrix<float16_t> & dy);
        void backprop(Matrix<float16_t> & dy, Matrix<float16_t> & original_input);
        float get_gradient(size_t index) {
            if (fabs(kernel[index]) >= 1) {
                return 0;
            } else {
                if (dkernel[index]) {
                    return 1.0/gradient_scale;
                } else {
                    return -1.0/gradient_scale;
                }
            }
        };
        Matrix<float16_t> & get_weight() {return kernel;};
};

#endif
        
//Matrix2D<float> forward(const Matrix2D<bool> & x, bool is_training=false);