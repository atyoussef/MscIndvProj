## Instructions

Please see our environment setup in `env.txt`.
To run our experiments, please go to `MNIST-CIFAR-SVHN` and execute `python Binary.py`.
Detailed settings of training runs can be modified in `Binary.py`. Neural network model can be modified in `model_architectures.py`.
